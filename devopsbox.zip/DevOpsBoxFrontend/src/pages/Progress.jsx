import React from "react";

const Progress = () => {
  return (
    <div>
      <h2>Your Progress</h2>
      <p>Track your completed challenges and learning stats here.</p>
    </div>
  );
};

export default Progress;
