import React from "react";

const Loader = () => <p>Loading...</p>;

export default Loader;
