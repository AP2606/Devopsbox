import React from "react";

const Topbar = () => {
  return (
    <header className="topbar">
      <h1>DevOps Practice Sandbox</h1>
    </header>
  );
};

export default Topbar;
